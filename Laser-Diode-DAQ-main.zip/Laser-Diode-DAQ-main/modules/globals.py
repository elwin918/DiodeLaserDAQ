# globals.py

# Global Variables
window, fram, anim = None, None, None
filename = "data.csv"
sampling_rate = 1
channel_vars = []
therm_curr = []
power_factors = []
total_time = 0
data = None